import os
import time
motorvalue = []

def Motormove():
    command = "rostopic pub -1 /sync_set_position dynamixel_sdk_examples/SyncSetPosition \"{"
    for i in range(1, 13):
        command += "id{0}: {0}, ".format(i)
    for i in range(1, 13):
        command += "position{0}: {1}, ".format(i, motorvalue[i-1])
    command = command[:-2]
    command += "}\"\n"
    os.system(command)
while True:
    motorvalue = [512, 640, 224, 512, 334, 800, 512, 384, 800, 512, 690, 224]
    Motormove()
    motorvalue = [512, 690, 224, 512, 384, 800, 512, 334, 800, 512, 640, 224]
    Motormove()
