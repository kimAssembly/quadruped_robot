import os
import rospy

motorvalues_sets = [
        [512, 384, 224, 512, 690, 800, 512, 640, 800, 512, 334, 224],
        [512, 334, 224, 512, 640, 800, 512, 690, 800, 512, 384, 224]]

for motorvalue in motorvalues_sets:
    command = "rostopic pub -1 /sync_set_position dynamixel_sdk_examples/SyncSetPosition \"{"
    for i in range(1, 13):
        command += "id{0}: {0}, ".format(i)

    for i, value in enumerate(motorvalue, start = 1):
        command += "position{0}: {1}, ".format(i, value)

    command = command[:-2]
    command += "}\"\n"
    os.system(command)
