import os
motorvalue = []

def Motormove(motorid, motorv):
    command = "rostopic pub -1 /set_position dynamixel_sdk_examples/SetPosition \"{"
    command += "id : {}, ".format(motorid)
    command += "position : {}, ".format(motorv)
    command = command[:-2]
    command += "}\"\n"
    os.system(command)
while True:
    motorvalue = [512, 384, 224, 512, 690, 800, 512, 640, 800, 512, 334, 224]
    Motormove(1,512)
    motorvalue = [512, 334, 224, 512, 640, 800, 512, 690, 800, 512, 384, 224]
    Motormove(1,512)
