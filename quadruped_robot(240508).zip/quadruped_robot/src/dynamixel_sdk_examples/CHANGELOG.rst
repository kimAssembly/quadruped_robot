^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package dynamixel_sdk_examples
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

3.7.41(2020-08-12)
-------------------
* DYNAMIXEL SDK ROS example initial commit.
* Bug fix for 4.5Mbps support (#430)
* Contributors: Zerom, Will Son
